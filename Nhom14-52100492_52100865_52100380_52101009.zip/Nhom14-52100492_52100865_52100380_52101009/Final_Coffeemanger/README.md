# winform-coffee

Kết nối cơ sở dữ liệu

-   Click chuột phải Database chọn Restores Database
    ![1682511274910](image/README/1682511274910.png)
-   Chọn Device rồi chọn dấu ...
    ![1682511453024](image/README/1682511453024.png)
-   Sau đó add QuanLyCoffeOngBau1.bak
    ![1682511505126](image/README/1682511505126.png)

Sau đó coffe\WinFormsApp1

tk đăng nhập phía :

1. admin :
   tk: 222
   mk: 222
2. nhân viên
   tk: 333
   mk:111
